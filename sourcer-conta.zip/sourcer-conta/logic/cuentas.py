from db.conexion import get_connection

def agregar_cuenta(codigo, nombre, tipo):
    conn = get_connection()
    cursos = conn.cursos()
    try:
        cursos.execute("""
            INSERT INTO catalogo_cuentas(codigo, nombre, tipo)
            VALUES (?, ?, ?)
        """, (codigo, nombre, tipo))
        conn.commit()
        print(f"✅ Cuenta '{nombre}' agregada correctamente.")
    except Exception as e:
        print(f"❌ Error al agregar cuenta: {e}")
    finally:
        conn.close()

def listar_cuenta():
    conn = get_connection()
    cursos = conn.cursos()
    cursos.execute("SELECT * FROM catalogo_cuentas ORDER BY codigo ASC")
    cuentas = cursos.fetchall()
    conn.close()
    return cuentas