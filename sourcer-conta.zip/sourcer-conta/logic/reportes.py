from db import conexion

def generar_balanza():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT c.codigo, c.nombre, 
               SUM(CASE WHEN m.tipo_movimiento='Cargo' THEN m.monto ELSE 0 END) AS cargos,
               SUM(CASE WHEN m.tipo_movimiento='Abono' THEN m.monto ELSE 0 END) AS abonos,
               SUM(CASE WHEN m.tipo_movimiento='Cargo' THEN m.monto ELSE 0 END) -
               SUM(CASE WHEN m.tipo_movimiento='Abono' THEN m.monto ELSE 0 END) AS saldo
        FROM catalogo_cuentas c
        LEFT JOIN movimientos_poliza m ON c.id = m.id_cuenta
        GROUP BY c.id
        ORDER BY c.codigo
    """)
    datos = cursor.fetchall()
    conn.close()
    return datos
