from db.conexion import get_connection

def crear_poliza(fecha, descripcion):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO polizas (fecha, descripcion)
        VALUES (?, ?)
    """, (fecha, descripcion))
    conn.commit()
    id_poliza = cursor.lastrowid
    conn.close()
    print(f"✅ Póliza creada con ID: {id_poliza}")
    return id_poliza

def agregar_movimiento(id_poliza, id_cuenta, tipo_movimiento, monto):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO movimientos_poliza (id_poliza, id_cuenta, tipo_movimiento, monto)
        VALUES (?, ?, ?, ?)
    """, (id_poliza, id_cuenta, tipo_movimiento, monto))
    conn.commit()
    conn.close()
    print("✅ Movimiento agregado correctamente.")
