from db.conexion import get_connection

def crear_tablas():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS catalogo_cuentas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT UNIQUE NOT NULL,
        nombre TEXT NOT NULL,
        tipo TEXT CHECK(tipo IN ('Activo','Pasivo','Cap
                         ital','Ingreso','Gasto')) NOT NULL
    );

    CREATE TABLE IF NOT EXISTS polizas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha DATE NOT NULL,
        descripcion TEXT
    );

    CREATE TABLE IF NOT EXISTS movimientos_poliza (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_poliza INTEGER,
        id_cuenta INTEGER,
        tipo_movimiento TEXT CHECK(tipo_movimiento IN ('Cargo','Abono')),
        monto REAL NOT NULL,
        FOREIGN KEY (id_poliza) REFERENCES polizas(id),
        FOREIGN KEY (id_cuenta) REFERENCES catalogo_cuentas(id)
    );
    """)

    conn.commit()
    conn.close()
    print("✅ Tablas creadas correctamente.")

if __name__ == "__main__":
    crear_tablas()
