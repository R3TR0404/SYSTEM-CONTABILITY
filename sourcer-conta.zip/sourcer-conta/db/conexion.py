import sqlite3
import os

#DB file nexto to this file
BASE_DIR =os.path.dirname(os.path.abspath(__file__))
DB_NAME = os.path.join(BASE_DIR, "contabilidad.db")


def get_connection():
    """Devuelve una conexión a la base de datos SQLite (ruta absoluta)."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

if __name__ == "__main__":
    #prueba rapida
    print("DB path: ", DB_NAME)
    if os.path.exists(DB_NAME):
        print("DB EXISTS")
    else:
        print("DB DOES NOT EXIST")