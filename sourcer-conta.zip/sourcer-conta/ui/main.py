from db.crear_tablas import crear_tablas
from logic.cuentas import agregar_cuenta, listar_cuentas
from logic.polizas import crear_poliza, agregar_movimiento
from logic.reportes import generar_balanza

def main():
    crear_tablas()

    print("=== Sistema Contable Minimalista ===\n")

    # Ejemplo de prueba:
    agregar_cuenta("1001", "Caja", "Activo")
    agregar_cuenta("2001", "Proveedores", "Pasivo")
    agregar_cuenta("4001", "Ventas", "Ingreso")

    id_poliza = crear_poliza("2025-10-10", "Venta al contado")
    agregar_movimiento(id_poliza, 1, "Cargo", 5000.0)
    agregar_movimiento(id_poliza, 3, "Abono", 5000.0)

    print("\n--- Balanza de Comprobación ---")
    for fila in generar_balanza():
        print(dict(fila))

if __name__ == "__main__":
    main()
